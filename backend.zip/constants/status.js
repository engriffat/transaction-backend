const STATUS = {
	SUCCESS: 'success',
	ERROR: 'error',
	FAIL: 'fail',
};

module.exports = STATUS;
