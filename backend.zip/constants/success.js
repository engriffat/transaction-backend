exports.SUCCESS_MESSAGES = {
    CREATED: 'Created Successfully',
    UPDATE: 'Updated Successfully',
    DELETE: 'Deleted',
};
