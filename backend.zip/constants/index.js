exports.ERRORS = require("./errors");
exports.SUCCESS_MSG = require("./success");
exports.STATUS = require("./status");
exports.STATUS_CODE = require("./statusCode");