// const axios = require('axios');
// const ethPrice = async() => {
    
//     console.log('Current Ethereum Price (USD):', ethPrice);
// }

// ethPrice()

// // Extract the current price from the response